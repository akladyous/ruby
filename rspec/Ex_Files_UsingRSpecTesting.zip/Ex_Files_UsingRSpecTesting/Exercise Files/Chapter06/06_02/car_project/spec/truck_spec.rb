require 'truck'
require 'shared_examples/a_standard_vehicle'

describe Truck do

  it_behaves_like('a standard vehicle')
  
end
