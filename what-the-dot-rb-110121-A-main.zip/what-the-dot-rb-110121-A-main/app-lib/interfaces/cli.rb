
# Just an Initialization Method

def initialize_app 

    puts "........"
    puts "yurrrr"
    puts "........"
    

    # / console.log("yurrrr")

    # binding.pry
    # to pause our Code in it's Tracks / `rake console`

    
    cli_menu


end 



def cli_menu

    puts "Welcome"

    gets.chomp

end
