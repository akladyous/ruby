require_relative "../config/environment"

initialize_app